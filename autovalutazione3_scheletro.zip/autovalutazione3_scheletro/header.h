#define NUM_UPDATES 3
#define MAX_VALUES 4
#define NUM_CONS 12

typedef struct {
	long type;
} req; 

typedef struct {
	long type;
	int value;
} res; 


